<template>
  <el-container class="correct">
    <el-main class="content">
      <content />
    </el-main>
    <el-main class="board">
      <board></board>
    </el-main>

    <el-main class="sideBar">
      <side-bar />
    </el-main>
  </el-container>
</template>


<script lang="ts">
import { defineComponent } from 'vue'

import board from './cpns/board/board.vue'
import content from './cpns/content/content.vue'
import sideBar from './cpns/side-bar/side-bar.vue'
import { useCorrectStore } from '@/store/correct/correct'

export default defineComponent({
  name: 'correct',
  components: {
    board,
    content,
    sideBar
  },
  setup() {
    // 测试用 加载对比结果
    useCorrectStore().GetCorrectRes()

    return {}
  }
})
</script>

<style scoped lang="less">
.correct {
  height: 100%;
}

.correct {
  // background-color: red;

  .content {
    width: 60%;
    // background-color: aquamarine;
  }

  .board {
    width: 30%;
    // background-color: lightsteelblue;
  }

  .sideBar {
    // background-color: lightgreen;
  }
}
</style>
