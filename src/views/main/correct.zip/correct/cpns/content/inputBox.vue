<template>
  <div
    class="inputBox"
    contenteditable="true"
    ref="inpMsgRef"
    v-text="msg"
    @input="inputMsg"
    @focus="isLocked = true"
    @blur="isLocked = false"
  ></div>
</template>

<script>
export default {
  data() {
    return {
      msg: this.value,
      isLocked: false
    }
  },
  props: {
    value: {
      type: String,
      default: ''
    }
  },
  methods: {
    inputMsg() {
      this.$emit('input', this.$el.innerHTML)
    }
  },
  computed: {},
  watch: {
    value(n, o) {
      if (!this.isLocked || !this.msg) {
        this.msg = this.value
      }
    }
  }
}
</script>

<style lang="less" scoped>
</style>
